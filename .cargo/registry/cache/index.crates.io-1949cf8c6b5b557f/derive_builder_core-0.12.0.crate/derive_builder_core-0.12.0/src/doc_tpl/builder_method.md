Builds a new `{struct_name}`.

# Errors

If a required field has not been initialized.
