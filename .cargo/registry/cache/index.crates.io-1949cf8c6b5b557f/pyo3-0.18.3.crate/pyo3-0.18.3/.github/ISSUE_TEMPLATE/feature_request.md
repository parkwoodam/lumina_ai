---
name: 💡 Feature request
about: Suggest an idea for this project
labels: [enhancement]
---

<!-- 
Thank you for sharing your idea!

Please describe your idea in depth. If you're not sure what to write, imagine the following:
  - How is this important to you? How would you use it?
  - Can you think of any alternatives?
  - Do you have any ideas about how it can be implemented? Are you willing/able to implement it? Do you need mentoring?
-->