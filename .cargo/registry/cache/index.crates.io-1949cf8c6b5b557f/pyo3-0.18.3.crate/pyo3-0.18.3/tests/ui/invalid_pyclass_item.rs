use pyo3::prelude::*;

#[pyclass]
fn foo() {}

fn main() {}
