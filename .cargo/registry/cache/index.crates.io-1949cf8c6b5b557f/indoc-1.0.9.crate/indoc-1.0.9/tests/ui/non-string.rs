use indoc::indoc;

fn main() {
    indoc!(64);
}
