stack!(stack_st_OPENSSL_STRING);
