use libc::*;

pub const PEM_R_NO_START_LINE: c_int = 108;
